# Email Signature Generator

## Run locally

```bash
npm install
npm run dev
```

## Build

```bash
npm run build
npm run preview
```
